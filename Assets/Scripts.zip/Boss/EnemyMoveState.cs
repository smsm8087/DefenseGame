﻿using Boss;
using UnityEngine;

public class BossMoveState : IBossState
{
    public void Enter(BossController boss)
    {
        boss.animator.Play("idle");
    }

    public void Update(BossController boss)
    {
        Vector3 dir = boss.serverPosition - boss.transform.position;
        if (dir.sqrMagnitude > 0.01f)
        {
            boss.transform.position = Vector3.Lerp(boss.transform.position, boss.serverPosition, Time.deltaTime * 5f);

            if (Mathf.Abs(dir.x) > 0.01f)
            {
                boss.spriteRenderer.flipX = dir.x < 0;
            }
        }
    }

    public void Exit(BossController boss) { }
}