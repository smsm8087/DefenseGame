﻿using System.Collections;
using Boss;
using UnityEngine;
using Enemy;

public class BossDeadState : IBossState
{
    public void Enter(BossController boss)
    {
        boss.animator.Play("dead");
    }

    public void Update(BossController boss)
    {
        
    }
    public void Exit(BossController boss) { }
}