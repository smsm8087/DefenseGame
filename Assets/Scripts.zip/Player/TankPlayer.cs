﻿using UnityEngine;

/// <summary>
/// 탱커
/// </summary>
public class TankPlayer : BasePlayer
{
    protected override void Awake()
    {
        base.Awake();
    }

    protected override void Start()
    {
        base.Start();
    }
}