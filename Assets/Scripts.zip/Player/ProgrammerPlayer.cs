﻿using UnityEngine;

public class ProgrammerPlayer : BasePlayer
{
    protected override void Awake()
    {
        base.Awake();
    }

    protected override void Start()
    {
        base.Start();
    }
}